package com.example.hashingservice;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

public class LoginManager {

    private Map<String, String> users;

    public LoginManager() {
        users = new HashMap<>();
    }

    public void registerUser(String username, String password) {
        String hashedPassword = hashPassword(password);
        users.put(username, hashedPassword);
    }

    public boolean loginUser(String username, String password) {
        if (users.containsKey(username)) {
            String hashedPassword = hashPassword(password);
            String storedPassword = users.get(username);
            return hashedPassword.equals(storedPassword);
        }
        return false;
    }

    private String hashPassword(String password) {
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = messageDigest.digest(password.getBytes());
            StringBuilder stringBuilder = new StringBuilder();

            for (byte hashByte : hashBytes) {
                stringBuilder.append(Integer.toString((hashByte & 0xff) + 0x100, 16).substring(1));
            }

            return stringBuilder.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }
}