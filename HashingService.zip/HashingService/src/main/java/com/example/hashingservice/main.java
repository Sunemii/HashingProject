package com.example.hashingservice;

import com.example.hashingservice.LoginManager;

import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        LoginManager loginManager = new LoginManager();
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to the Login Manager!");

        while (true) {
            System.out.println("\n1. Register a new user");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("Select an option: ");

            int option = scanner.nextInt();

            if (option == 1) {
                System.out.print("Enter username: ");
                String username = scanner.next();
                System.out.print("Enter password: ");
                String password = scanner.next();

                loginManager.registerUser(username, password);
                System.out.println("User registered successfully!");
            } else if (option == 2) {
                System.out.print("Enter username: ");
                String username = scanner.next();
                System.out.print("Enter password: ");
                String password = scanner.next();

                if (loginManager.loginUser(username, password)) {
                    System.out.println("Login successful!");
                } else {
                    System.out.println("Invalid username or password!");
                }
            } else if (option == 3) {
                break;
            } else {
                System.out.println("Invalid option! Please try again.");
            }
        }

        System.out.println("\nThank you for using the Login Manager!");
    }
}