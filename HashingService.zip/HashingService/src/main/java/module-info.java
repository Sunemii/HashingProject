module com.example.hashingservice {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.hashingservice to javafx.fxml;
    exports com.example.hashingservice;
}